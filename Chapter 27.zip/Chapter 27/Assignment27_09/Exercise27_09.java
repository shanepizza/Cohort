/* 
Author: 
Date:

Given: "4.5"      Expected: 51451
Given: "Hello"    Expected: 69609650
*/
import java.math.*;

public class Exercise27_09 { 
  public static void main(String[] args) {
    String s = "4.5";
    System.out.println(hashCodeForString(s));
    
    s = "Hello";
    System.out.println(hashCodeForString(s));
  }
  
  public static int hashCodeForString(String s) {
    // Add your code here
    String h = s;
    int b = 31;
    int hashCode = 0;
  
    for(int i = 0; i != h.length(); i++){
      hashCode = hashCode * b + h.charAt(i);
    }//end for loop.
    
    return hashCode;
  }//end Main
}//end Class