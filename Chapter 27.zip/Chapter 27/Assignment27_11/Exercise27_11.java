/*
Adam Calring
April 3, 2019

Code takes a hashset and puts it into an array list. It will then display the list of names.

*/

import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;import java.util.*;


public class Exercise27_11 {
  public static void main(String[] args) {
    Set<String> set = new HashSet<String>(); 
    set.add("Smith");
    set.add("Anderson");
    set.add("Lewis");
    set.add("Cook"); 
    set.add("Smith");
    
    ArrayList<String> list = setToList(set);
    System.out.println(list);
  }
  
  public static <E> ArrayList<E> setToList(Set<E> s) {
    Set a = s;
    ArrayList<E> fini = new ArrayList<E>();
    Iterator<E> itr = a.iterator();
   
    while(itr.hasNext()){
      fini.add(itr.next());
    }
    
    //System.out.println(fini);
    return fini;
  }
}
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  